Information for compiling and running the program.
