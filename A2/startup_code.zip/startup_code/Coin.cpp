#include "Coin.h"
 
 // implement functions for managing coins; this may depend on your design.
